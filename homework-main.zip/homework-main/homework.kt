package com.example.myapplication

fun main (){
    var x: Int = 10
    var y: Int = 3
    var m: Int = 6
    var p: Int = 2
    val z: Int = 5
    val r: Int= 5
    val on :Boolean = true
    val off: Boolean = false
    val s = x%y
    val h =z-y*p
    val e = y!=p
    val l = (m+m)/y

    println(" the result : ${off && on}")
    println("$s")
    println(" ${z >= r}")
    println(" the result: ${off || on}")
    println("$h")
    println("$e")
    println("$l")

}